# Gerar o .jar pelo GitHub

1. Crie um repositório no GitHub e suba TODO o conteúdo desta pasta
   (a pasta `.github` precisa ir junto).
2. Vá na aba **Actions** → workflow **Build** → espere ficar verde
   (ele roda sozinho a cada push; ou clique em *Run workflow*).
3. Abra a execução e baixe **waterfisic-jar** em *Artifacts*.
   Dentro do zip está o `waterfisic-1.0.0.jar` (use o que NÃO termina em `-sources`).
4. Coloque o jar em `.minecraft/mods` (Minecraft 1.21.1 + Fabric Loader + Fabric API).

## Release automática (opcional)
    git tag v1.0.0
    git push origin v1.0.0
O jar aparece em **Releases**.

## Build local
Precisa de Java 21 e Gradle 8.8+:
    gradle build
Jar em `build/libs/waterfisic-1.0.0.jar`.
