package com.waterfisic;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.gl.GlUniform;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.util.math.Vec3d;

/**
 * Entrega ao shader da água a fase das ondas na posição da câmera.
 * O shader (assets/minecraft/shaders/core/rendertype_translucent.vsh) levanta a superfície
 * de TODA a água do jogo usando as mesmas ondas da física dos barcos.
 */
public final class Visual {
    private static final double DOIS_PI = Math.PI * 2.0;

    private Visual() {
    }

    public static void iniciar() {
        WorldRenderEvents.START.register(ctx -> {
            try {
                ShaderProgram prog = GameRenderer.getRenderTypeTranslucentProgram();
                if (prog == null || ctx.world() == null) {
                    return;
                }
                GlUniform u1 = prog.getUniform("AguaFase");
                GlUniform u2 = prog.getUniform("AguaFase2");
                if (u1 == null) {
                    return;
                }
                Vec3d cam = ctx.camera().getPos();
                double f1 = mod(cam.x * 0.42 + cam.z * 0.27);
                double f2 = mod(-cam.x * 0.21 + cam.z * 0.5);
                double f3 = mod(cam.x * 0.9 + cam.z * 0.6);
                float amp = (float) Math.min(1.6, Ondas.amplitude(ctx.world(), 1.0F));
                boolean ligado = Config.I.intensidade > 0 && Config.I.altura > 0;
                u1.set((float) f1, (float) f2, amp, ligado ? 1.0F : 0.0F);
                if (u2 != null) {
                    u2.set((float) f3, 0.0F, 0.0F, 0.0F);
                }
            } catch (Throwable ignored) {
                // se algo mudar no jogo, a água simplesmente fica sem onda (nunca trava)
            }
        });
    }

    private static double mod(double v) {
        double r = v % DOIS_PI;
        return r < 0 ? r + DOIS_PI : r;
    }
}
