package com.waterfisic;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Configuração salva em config/waterfisic.json. */
public final class Config {
    /** Força das ondas em % (0 = desligado, 100 = padrão, 400 = máximo). */
    public int intensidade = 100;
    /** Força da correnteza/deriva em % (0 = sem deriva). */
    public int correnteza = 100;
    /** Tamanho das ondas em % (a água sobe e desce de verdade). 100 = padrão. */
    public int altura = 150;
    /** Densidade de espuma, respingos e cachoeiras em % (0 = desligado). */
    public int particulas = 150;
    /** Se verdadeiro, ondas gigantes da tempestade derrubam os passageiros do barco. */
    public boolean perigo = false;

    public static Config I = new Config();

    private static Path arquivo() {
        return FabricLoader.getInstance().getConfigDir().resolve("waterfisic.json");
    }

    public static void carregar() {
        try {
            Path a = arquivo();
            if (Files.exists(a)) {
                Config c = new Gson().fromJson(Files.readString(a), Config.class);
                if (c != null) {
                    I = c;
                }
            } else {
                salvar();
            }
        } catch (Exception e) {
            I = new Config();
        }
    }

    public static void salvar() {
        try {
            Files.writeString(arquivo(), new GsonBuilder().setPrettyPrinting().create().toJson(I));
        } catch (Exception ignored) {
            // sem problema: só não salva
        }
    }
}
