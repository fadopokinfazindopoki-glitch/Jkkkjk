package com.waterfisic;

import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Aplica a força das ondas em barcos, nadadores e itens. */
public final class Fisica {
    private Fisica() {
    }

    public static void tick(World world, Iterable<Entity> entidades) {
        if (Config.I.intensidade <= 0) {
            return;
        }
        for (Entity e : entidades) {
            if (e instanceof BoatEntity boat) {
                barco(world, boat);
                if (world instanceof ServerWorld sw) {
                    efeitosDoBarco(sw, boat);
                }
            } else if (!world.isClient && (e instanceof LivingEntity || e instanceof ItemEntity)) {
                leve(world, e);
            }
        }
    }

    /**
     * Barco: sobe e desce com a onda, escorrega pela inclinação, vai à deriva e surfa nas cristas.
     * Só age no lado que controla o barco (cliente do piloto, ou servidor se estiver vazio).
     */
    private static void barco(World world, BoatEntity boat) {
        if (!boat.isTouchingWater() || !boat.isLogicalSideForUpdatingMovement()) {
            return;
        }
        double[] o = Ondas.avaliar(boat.getX(), boat.getZ(), world.getTime());
        double amp = Ondas.amplitude(world, 1.0F) * Ondas.fatorProfundidade(world, boat.getBlockPos());
        double d = Config.I.correnteza / 100.0;

        double vy = amp * o[2] * 1.8;
        double ax = -o[0] * amp * 0.10 + Ondas.DERIVA_X * 0.03 * amp * d;
        double az = -o[1] * amp * 0.10 + Ondas.DERIVA_Z * 0.03 * amp * d;

        Vec3d v = boat.getVelocity();
        boat.setVelocity(v.x + ax, v.y + vy, v.z + az);
        if (!world.isClient) {
            boat.velocityModified = true;
        }
    }

    /** Respingos, batidas de onda e ondas gigantes (só no servidor). */
    private static void efeitosDoBarco(ServerWorld world, BoatEntity boat) {
        if (!boat.isTouchingWater()) {
            return;
        }
        double amp = Ondas.amplitude(world, 1.0F) * Ondas.fatorProfundidade(world, boat.getBlockPos());
        double tempestade = Ondas.tempestade(world);

        // Respingo de onda batendo no casco: mais frequente com mar agitado.
        int freq = Math.max(3, (int) (16 - amp * 28.0));
        if (world.random.nextInt(freq) == 0) {
            double[] o = Ondas.avaliar(boat.getX(), boat.getZ(), world.getTime());
            if (o[3] > 0.2) {
                double fx = -Math.sin(Math.toRadians(boat.getYaw()));
                double fz = Math.cos(Math.toRadians(boat.getYaw()));
                world.spawnParticles(ParticleTypes.SPLASH, boat.getX() + fx * 0.9, boat.getY() + 0.35,
                        boat.getZ() + fz * 0.9, 3 + (int) (amp * 14.0), 0.35, 0.1, 0.35, 0.05);
            }
        }

        // Batida de onda no casco.
        if (amp > 0.15 && world.random.nextInt(70) == 0) {
            world.playSound(null, boat.getX(), boat.getY(), boat.getZ(), SoundEvents.ENTITY_GENERIC_SPLASH,
                    SoundCategory.NEUTRAL, (float) Math.min(1.0, 0.25 + amp), 0.7F + world.random.nextFloat() * 0.4F);
        }

        // Onda gigante: só em tempestade.
        if (tempestade > 0.5 && world.random.nextInt(1200) == 0) {
            ondaGigante(world, boat);
        }
    }

    private static void ondaGigante(ServerWorld world, BoatEntity boat) {
        double d = Config.I.correnteza / 100.0;
        double forca = 0.30 + 0.25 * Config.I.intensidade / 100.0;
        Vec3d v = boat.getVelocity();
        boat.setVelocity(v.x + Ondas.DERIVA_X * forca * d, v.y + 0.35, v.z + Ondas.DERIVA_Z * forca * d);
        boat.velocityModified = true;

        world.playSound(null, boat.getX(), boat.getY(), boat.getZ(), SoundEvents.ENTITY_GENERIC_SPLASH,
                SoundCategory.NEUTRAL, 1.6F, 0.55F);
        world.spawnParticles(ParticleTypes.SPLASH, boat.getX(), boat.getY() + 0.5, boat.getZ(), 60, 0.9, 0.4, 0.9, 0.2);
        world.spawnParticles(ParticleTypes.BUBBLE, boat.getX(), boat.getY() + 0.2, boat.getZ(), 25, 0.7, 0.3, 0.7, 0.1);

        if (Config.I.perigo) {
            boat.removeAllPassengers();
        }
    }

    /** Jogador nadando, mobs e itens na água: são levados pela correnteza das ondas. */
    private static void leve(World world, Entity e) {
        if (!e.isTouchingWater() || e.hasVehicle() || e.isSpectator()) {
            return;
        }
        double[] o = Ondas.avaliar(e.getX(), e.getZ(), world.getTime());
        double amp = Ondas.amplitude(world, 1.0F) * Ondas.fatorProfundidade(world, e.getBlockPos()) * 0.8;
        double d = Config.I.correnteza / 100.0;

        double ax = -o[0] * amp * 0.07 + Ondas.DERIVA_X * 0.02 * amp * d;
        double az = -o[1] * amp * 0.07 + Ondas.DERIVA_Z * 0.02 * amp * d;

        e.addVelocity(ax, 0.0, az);
        e.velocityModified = true;
    }
}
